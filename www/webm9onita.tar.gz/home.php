<?php 
	require("include.php");
	require("menu.php");
?>

<div id="page">
	<div id="content">
		<?php require("tahuisi.php");	?>
	</div> 
	<!-- end div content -->
	
	<div id="sidebar">
		<?php 
//			require("sidebar.php");	
		?>
	</div> 
	<!-- end div sidebar -->

	<div style="clear: both;">&nbsp;</div>
</div> 
<!-- end div page -->

<?php
	require("footer.php");
?>
