<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo $judulWeb ?></title>
<meta name="keywords" content="monita, online monitoring system, diesel, pressure, temperature, flow" />
<meta name="description" content="monita, online monitoring system, diesel, pressure, temperature, flow" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="../dojo/dojo.js"></script>
<script type="text/javascript" src="./kantor.js"></script>
<script type="text/javascript" src="./grafik.js"></script>
</head>

<body onload="startup()">
<!--div id="tombol">qwerty</div-->
<div id="wrapper">
<div id="wrapper2">
