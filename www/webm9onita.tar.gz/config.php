<?
	$judulWeb = ":: Monita, Online Monitoring System";	// tampil di Judul Browser
	$nama_produk = "Sistem Monitoring Online";			// tampil di header web
	$tahun = "2009";			// tahun instalasi monita, tampil di footer
	$almtWebClient = "";		// format = http://www.xxx.com, Website PLN / PLTD Setempat

	$rek = 11;		// default jml rekaman grafik (11 data)
	$tf = 5000;		// default periode ambil data (= 5 detik)
	$c_id_dept = 0;

	//global $equipment;
?>
