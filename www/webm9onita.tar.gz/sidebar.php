<?php

?>

<div id="logSheet">
	<form target="_blank" action="logsheet.php" method="get">
		<b style="font-size: 20px;">LogSheet</b><br /><br />Tanggal<br />
			<input id="tanggal" dojoType="dropdowndatepicker" name="tgl" value="today" displayFormat="dd-MM-yyyy" containerToggle="fade">
			<br /><br />
			<input id="excel" type="submit" value="  Lihat Excel  "/>
			</form>
</div>
