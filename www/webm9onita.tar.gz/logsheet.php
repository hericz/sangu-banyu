<?php

echo "ini halaman logsheet format excel";

?>

Hasil excel : <a href="http://192.168.1.72/data/PHPExcel-25181/Tests/27imagesexcel5.xls">ini</a>
