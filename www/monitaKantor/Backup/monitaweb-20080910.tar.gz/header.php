<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>:: Monita, online monitoring system ::</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styleX.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="kantor.js"></script>
</head>

<body onload="startup()">
<!--div id="tombol">qwerty</div-->
<div id="wrapper">
<div id="wrapper2">