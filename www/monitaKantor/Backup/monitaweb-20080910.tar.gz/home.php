<?php 
	require("include.php");
	
	$c_id_dept= $_GET['id'];
	require("menu.php");
?>

<div id="page">
	<div id="content">
		<div id="tahuIsi">
		<br><br><br><br><br><br><br><br><br><br><br><br>
		</div>
	</div>
	<div id="sidebar"></div>

	<!--div style="clear: both;">&nbsp;</div-->
</div>

<?php
	$a = 54;
	//echo "nilai a :" . $a . "<br>";
?>

<?php
	//echo "nilai a :" . $a . "<br>";
	require("footer.php");
?>
