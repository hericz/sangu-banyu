<?php 
	//global $nDept;
	//global $c_id_dept;
	//echo "nilai a :" . $a . "<br>";
	$c_id_dept = $_GET['id'];
	//echo "id : " . $c_id_dept . " nDept : " . $nDept;
	//echo "isi : " . $dept[0]["nama"] . " " ;
?>
</div>
<div id="footerX"><p>Monita terselenggara atas kerja sama<br><?php /*echo $dept[$nDept]["nama"] . ", " . $prsh[$nPrsh]["nama"]//*/ ?> bersama <a href="http://www.daunbiru.com">daunbiru</a><br>2007</div></p></div>
</div>
<!-- end #wrapper -->
</body>
</html>
